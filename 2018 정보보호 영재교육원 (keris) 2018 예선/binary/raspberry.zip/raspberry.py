import hashlib

def printFlag():
	print "Flag is XXX"

def rshift(val, n):
	m = 1 << 128

	if ((val & m) == 0):
		return val >> n
	else:
		for i in range(0, n):
			val = (val >> 1) | m
		return val

def check_passcode(passcode, val):
	m = hashlib.md5()
	m.update(passcode)
	passcode = rshift(int(m.hexdigest(), 16), 112) << 112
	
	a = rshift((1 << 128), 16)

	if(passcode == (a & val)):
		printFlag()
	else:
		print "Wrong!"
		exit(0)

passcode = raw_input("Enter passcode >> ")

if(passcode.isdigit()):
	check_passcode(passcode, 0xefb6157e75017dc7134a16ff507fcf34)
	
else:
	print "You can only enter numbers!"
	exit(0)